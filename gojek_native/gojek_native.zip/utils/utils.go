package utils

import (
	"bytes"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io/ioutil"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/bcrypt"
)

func Hash(password string) ([]byte, error) {
	return bcrypt.GenerateFromPassword([]byte(password), bcrypt.MinCost)
}
func UploadImageBase64(fileNameBase string, content string) error {

	decode, err := base64.StdEncoding.DecodeString(content)
	if err != nil {
		return err
	}

	file, err := os.Create(fileNameBase)
	if err != nil {
		return err
	}

	defer file.Close()
	_, err = file.Write(decode)
	if err != nil {
		return err
	}

	return err
}
func UploadImageBase64ByFormat(pathImage, fileName string, content string) (string, error) {
	idx := strings.Index(content, ";base64,")
	if idx < 0 {
		return "", errors.New("Invalid image!")
	}

	reader := base64.NewDecoder(base64.StdEncoding, strings.NewReader(content[idx+8:]))
	buff := bytes.Buffer{}
	_, err := buff.ReadFrom(reader)
	if err != nil {
		return "", err
	}
	imgCfg, fmt, err := image.DecodeConfig(bytes.NewReader(buff.Bytes()))
	if err != nil {
		return "", err
	}
	if fmt == "jpeg" || fmt == "jpg" || fmt == "png" {

	} else {
		return "", errors.New("Invalid image!")
	}
	//jika validasi ukuran gambar
	if imgCfg.Width < 100 || imgCfg.Height < 100 {
		return "", errors.New("Invalid size image!")
	}

	fileNameBase := pathImage + fileName + "." + fmt
	ioutil.WriteFile(fileNameBase, buff.Bytes(), 0644)

	/*file, err := os.Create(fileNameBase)
	if err != nil {
		return "", err
	}
	defer file.Close()
	_, err = io.Copy(file, reader)
	if err != nil {
		return "", err
	}*/

	return fileName + "." + fmt, err

}
func NextRandom() string {

	var rand uint32
	var randmu sync.Mutex
	randmu.Lock()
	rr := rand
	if rr == 0 {
		rr = uint32(time.Now().UnixNano() + int64(os.Getpid()))
	}
	rr = rr*1664525 + 1013904223 // constants from Numerical Recipes
	rand = rr
	randmu.Unlock()
	return strconv.Itoa(int(1e9 + rr%1e9))[1:]
}

// RandomUIID is
func RandomUIID(bytenya int, lenReturn int) (string, error) {
	var err error
	b := make([]byte, bytenya)
	_, err = rand.Read(b)
	if err != nil {
		//fmt.Println("Error: ", err)
		return "", err
	}
	uuid := ""
	if lenReturn == 2 {
		uuid = fmt.Sprintf("%X", b[0:lenReturn])
	} else if lenReturn == 4 {
		uuid = fmt.Sprintf("%X", b[0:lenReturn])

	} else if lenReturn == 6 {
		uuid = fmt.Sprintf("%X", b[0:lenReturn])
	} else {
		uuid = fmt.Sprintf("%X", b[0:])
	}
	return uuid, err

}

// GetURL is
func GetURL(url string) (resp *http.Response, err error) {
	var netTransport = &http.Transport{
		Dial: (&net.Dialer{
			Timeout: 5 * time.Second,
		}).Dial,
		TLSHandshakeTimeout: 5 * time.Second,
	}
	var netClient = &http.Client{
		Timeout:   time.Second * 10,
		Transport: netTransport,
	}

	//fmt.Println(url)
	//req, err := http.NewRequest("GET", url, nil)
	resp, err = netClient.Get(url)
	return resp, err
}
