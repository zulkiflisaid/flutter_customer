package models

import (
	"github.com/zulkiflisaid/coba/configs"
)

// ModelGetCount is ...
func ModelGetCount(tables string) (uint64, error) {
	var err error
	var RowCoont uint64
	RowCoont = 0

	db := configs.Conn()
	selCountDB, err := db.Query("SELECT count(*) as count_data FROM " + tables)
	if err != nil {
		return 0, err
	}
	defer db.Close()
	for selCountDB.Next() {
		err = selCountDB.Scan(&RowCoont)
		if err != nil {
			return 0, err
		}
	}

	return RowCoont, err
}
