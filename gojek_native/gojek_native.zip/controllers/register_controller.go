package controllers

//import (
//	"fmt"
//	"net/http"
//)

//func Index1(w http.ResponseWriter, r *http.Request) {
//	fmt.Fprintf(w, "hello\n")
//}

import (
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strconv"
	"time"

	"github.com/zulkiflisaid/coba/configs"
	"github.com/zulkiflisaid/coba/responses"
	"github.com/zulkiflisaid/coba/structs"
	"github.com/zulkiflisaid/coba/utils"
	"gopkg.in/go-playground/validator.v9"
)

// Register is ...
func Register(w http.ResponseWriter, r *http.Request) {

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}
	m := structs.UserRegister{}
	err = json.Unmarshal(body, &m)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}
	pinregister := rand.Intn(999999-100000) + 100000
	db := configs.Conn()

	//filter register by
	var tblRegister string
	if m.Kat == "customer" {
		tblRegister = "customers"
	} else if m.Kat == "motor" || m.Kat == "car4" || m.Kat == "car6" {
		tblRegister = "drivers"
	} else if m.Kat == "resto" {
		tblRegister = "restaurants"
	} else if m.Kat == "cook" {
		tblRegister = "cooks"
	} else if m.Kat == "shop" {
		tblRegister = "shops"
	} else {
		responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
		return
	}

	m.PrepareUserRegister()
	validate = validator.New()
	err = validate.Struct(m)
	if err != nil {
		responses.ERROR_validation(w, http.StatusUnprocessableEntity, err)
		return
	}
	password, err := utils.Hash(m.Password)
	if err != nil {
		responses.ERROR(w, http.StatusUnprocessableEntity, err)
		return
	}
	var insForm sql.Result
	if tblRegister == "drivers" {
		insForm, err = db.Exec("INSERT INTO "+tblRegister+"(name,email,phone_number,phone_id,password,pin_register,gcm,category_driver) VALUES (?,?,?,?,?,?,?,?)",
			m.Name,
			m.Email,
			m.PhoneNumber,
			m.PhoneID,
			password,
			pinregister,
			m.Gcm,
			m.Kat,
		)
	} else {
		insForm, err = db.Exec("INSERT INTO "+tblRegister+"(name,email,phone_number,phone_id,password,pin_register,gcm) VALUES (?,?,?,?,?,?,?)",
			m.Name,
			m.Email,
			m.PhoneNumber,
			m.PhoneID,
			password,
			pinregister,
			m.Gcm,
		)
	}

	defer db.Close()
	if err != nil {
		responses.ERROR_mysql(w, http.StatusUnprocessableEntity, err)
		return
	}
	//id, err := insForm.LastInsertId()
	RowsAff, err := insForm.RowsAffected()
	if err != nil {
		responses.ERROR_mysql(w, http.StatusUnprocessableEntity, err)
		return
	}
	//fmt.Println(int(id))
	//fmt.Println(int(RowsAff))
	if RowsAff == 1 {
		err := SendGcmRegister(db, pinregister, m.PhoneID, m.PhoneNumber, m.Name)
		if err != nil {
			responses.JSON(w, http.StatusOK, json.RawMessage(`{"status": true}`))
			return
		}

		responses.JSON(w, http.StatusOK, json.RawMessage(`{"status": true}`))
		return

	}

	responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
	return
}

// SendGcmRegister is ...
func SendGcmRegister(db *sql.DB, pinregister int, PhoneID string, PhoneNumber uint64, Name string) error {
	//kirim gcm new register
	selDB, err := db.Query("SELECT gcm,key_server FROM gcms WHERE id=?", "1")
	if err != nil {
		return err
	}
	gcmServer := structs.GcmServer{}
	for selDB.Next() {
		var gcm, key string
		err = selDB.Scan(&gcm, &key)
		if err != nil {
			return err
		}
		gcmServer.Gcm = gcm
		gcmServer.Key = key
	}
	var Pin = strconv.Itoa(pinregister)
	gcmData := structs.GcmData{
		ID:                Pin,
		Body:              "Ada Pelanggan baru",
		Title:             "Ada Pelanggan baru",
		Message:           "Ada Pelanggan baru",
		NewRegister:       "baru",
		PhoneNumber:       PhoneID + strconv.FormatInt(int64(PhoneNumber), 10),
		Pin:               Pin,
		Name:              Name,
		ClickActionstring: "FLUTTER_NOTIFICATION_CLICK",
	}
	gcmFormat := structs.GcmFormat{
		To:       gcmServer.Gcm,
		Priority: "high",
		Data:     gcmData,
	}

	byteArray, err := json.Marshal(gcmFormat)
	if err != nil {
		return err
	}
	fmt.Println(string(gcmServer.Gcm))
	fmt.Println(string(byteArray))

	url := "https://fcm.googleapis.com/fcm/send"
	fmt.Println(url)
	//req, err := http.NewRequest("POST", "https://fcm.googleapis.com/fcm/send", bytes.NewBuffer(byteArray))
	req, err := utils.GetURL(url)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "key="+gcmServer.Key)
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req.Request)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	return err
}

// ValidasiRegister is ...
func ValidasiRegister(w http.ResponseWriter, r *http.Request) {
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	validasiPinRegister := structs.ValidasiPinRegister{}
	err = json.Unmarshal(body, &validasiPinRegister)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	validate = validator.New()
	err = validate.Struct(validasiPinRegister)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	tblRegister := ""
	status := 3
	if validasiPinRegister.KatUser == "customer" {
		tblRegister = "customers"
		status = 1
	} else if validasiPinRegister.KatUser == "driver" {
		tblRegister = "drivers"
	} else if validasiPinRegister.KatUser == "resto" {
		tblRegister = "restaurants"
	} else if validasiPinRegister.KatUser == "cook" {
		tblRegister = "cooks"
	} else if validasiPinRegister.KatUser == "shop" {
		tblRegister = "shops"
	} else {
		responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
		return
	}

	db := configs.Conn()
	selDB, err := db.Query("SELECT id  FROM "+tblRegister+" WHERE pin_register=? AND phone_id=?  AND phone_number=?  AND status=?   limit 1",
		validasiPinRegister.Pin,
		validasiPinRegister.PhoneID,
		validasiPinRegister.PhoneNumber,
		0)
	defer db.Close()
	if err != nil {
		responses.ERROR(w, http.StatusUnprocessableEntity, err)
		return
	}

	for selDB.Next() {
		var id uint64
		id = 0
		err = selDB.Scan(&id)
		if err != nil {
			responses.ERROR(w, http.StatusUnprocessableEntity, err)
			return
		}
		if id != 0 {
			currentTime := time.Now()
			updateForm, err := db.Exec("UPDATE "+tblRegister+" SET status=?,updated_at=?   WHERE id=?",
				status,
				currentTime.Format("2006.01.02 15:04:05"),
				id)
			defer db.Close()
			if err != nil {
				responses.ERROR(w, http.StatusUnprocessableEntity, err)
				return
			}

			RowsAff, err := updateForm.RowsAffected()
			if err != nil {
				responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
				return
			}
			if RowsAff == 1 {
				responses.JSON(w, http.StatusOK, json.RawMessage(`{"status": true}`))
				return
			}
		}
	}
	responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
	return
}
