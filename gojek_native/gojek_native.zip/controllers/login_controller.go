package controllers

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"log"
	"net/http"

	"github.com/zulkiflisaid/coba/auth"
	"github.com/zulkiflisaid/coba/configs"
	"github.com/zulkiflisaid/coba/responses"
	"github.com/zulkiflisaid/coba/structs"
	"gopkg.in/go-playground/validator.v9"

	//_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)

var validate *validator.Validate

// VerifyPassword is ...
func VerifyPassword(hashedPassword, password string) error {
	return bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
}

// Login is ...
func Login(w http.ResponseWriter, r *http.Request) {

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	userLogin := structs.UserLogin{}
	err = json.Unmarshal(body, &userLogin)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	var tblLogin string
	if userLogin.KatLogin == "customer" {
		tblLogin = "customers"
	} else if userLogin.KatLogin == "driver" {
		tblLogin = "drivers"
	} else if userLogin.KatLogin == "resto" {
		tblLogin = "restaurants"
	} else if userLogin.KatLogin == "cook" {
		tblLogin = "cooks"
	} else if userLogin.KatLogin == "shop" {
		tblLogin = "shops"
	} else if userLogin.KatLogin == "admin" {
		tblLogin = "admins"
	} else {
		responses.ERROR(w, http.StatusBadRequest, errors.New("Bad Request"))
		return
	}

	log.Println(string(body))
	userLogin.PrepareUserLogin()
	validate = validator.New()
	err = validate.Struct(userLogin)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}

	tokenRespon, err := SignIn(userLogin.Email, userLogin.Password, tblLogin)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
		return
	}
	byteArray, err := json.Marshal(tokenRespon)
	if err != nil {
		responses.ERROR(w, http.StatusBadRequest, err)
	}

	responses.JSON(w, http.StatusOK, json.RawMessage(string(byteArray)))
}

// SignIn is ...
func SignIn(email, password, tblLogin string) (structs.TokenRespon, error) {

	var err error

	userLogin := structs.UserLogin{}
	tokenRespon := structs.TokenRespon{
		Status: true,
		Token:  "",
	}
	db := configs.Conn()
	selDB, err := db.Query("SELECT  id,  email,  password,  status FROM "+tblLogin+" WHERE email=? limit 1", email)
	defer db.Close()
	if err != nil {
		return tokenRespon, err
	}

	for selDB.Next() {
		var id uint64
		var email, pass string
		var status int
		status = 0
		email = ""
		err = selDB.Scan(&id, &email, &pass, &status)
		if err != nil {
			return tokenRespon, err
		}

		userLogin.ID = id
		userLogin.Password = pass
		userLogin.Email = email
		userLogin.KatLogin = tblLogin
		userLogin.Status = status
		//log.Println(pass)
	}
	if email == "" {
		return tokenRespon, errors.New("Usename dan Password tidak ditemukan")
	}
	if userLogin.Status == 0 {
		return tokenRespon, errors.New("Nomor HP belum divalidasi")
	}
	if userLogin.Status == 2 {
		return tokenRespon, errors.New("Akun anda sedang diblok oleh sistem")
	}
	if userLogin.Status == 3 {
		return tokenRespon, errors.New("Akun anda belum dovalidasi oleh sistem")
	}

	err = VerifyPassword(userLogin.Password, password)
	if err != nil && err == bcrypt.ErrMismatchedHashAndPassword {
		return tokenRespon, err
	}
	var token string
	token, err = auth.CreateToken(userLogin.ID, tblLogin)
	if err != nil {
		return tokenRespon, err
	}
	tokenRespon.Status = true
	tokenRespon.Token = token
	//log.Println(token)

	return tokenRespon, nil
	//return auth.CreateToken(userLogin.ID)
}
