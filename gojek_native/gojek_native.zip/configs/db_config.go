package configs

import (
	"database/sql"
)

//Conn is
func Conn() (db *sql.DB) {
	dbDriver := "mysql"
	dbUser := "root"
	dbPass := ""
	dbName := "fullstack_api"
	db, err := sql.Open(dbDriver, dbUser+":"+dbPass+"@/"+dbName)
	if err != nil {
		panic(err.Error())
	}
	return db
}

//ConfigURL is
func ConfigURL() string {
	return "http://localhost:8080/"
}

//KeyAPIMap is ...
func KeyAPIMap() string {
	//asli dari akun zulcompoubd
	//return "AIzaSyA706610W0aD4w2ueNR6seGrlHj5SpYOyM"
	//https://distan.gorontaloprov.go.id/data-alsintan/
	return "AIzaSyBTokiA2EScfsUgZeuTcsTdpcrV11qAw8E"
}
